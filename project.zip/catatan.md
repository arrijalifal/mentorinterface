# 10/03/2025
- Ngatur layout biar enak dilihat`
- Ubah POV kamera

# 12/03/2025
- nambahin fitur forward kinematics & invers kinematics
- tambah websocket
- 