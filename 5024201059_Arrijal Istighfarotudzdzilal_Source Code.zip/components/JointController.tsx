import React from 'react'

const JointController = () => {
  return (
    <></>
  )
}

export default JointController