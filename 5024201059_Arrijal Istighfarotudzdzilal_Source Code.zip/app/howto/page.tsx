export default function HowTo() {
    return <div></div>
}