import React from 'react'

const Playground = () => {
  return (
    <div>Playground</div>
  )
}

export default Playground