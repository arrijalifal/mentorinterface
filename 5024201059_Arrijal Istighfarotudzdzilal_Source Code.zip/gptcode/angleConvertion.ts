const FILTER_SIZE = 32;
const angleBuffers: number[][] = Array.from({length: 6}, () => []);
let currentAngles: number[] = Array(6).fill(0);

// Fungsi modifikasi servo value (mirror + offset seperti Python)
function adjustServoValue(i: number, val: number): number {
  switch (i) {
    case 0:
      return 4096 - val + 580;
    case 1:
      return 4096 - val + 1024;
    case 4:
      return 4096 - val;
    default:
      return val;
  }
}

// Konversi ke sudut -180° sampai 180°
function servoToAngle(val: number): number {
  if (val < 0 || val > 4096) {
    throw new Error('servo_value must be between 0 and 4096');
  }
  return (val * 360 / 4096) - 180;
}

// Update filter buffer dan kembalikan sudut hasil smoothing
export function updateFilteredAngles(rawValues: number[]): number[] {
  const filtered: number[] = [];

  for (let i = 0; i < 6; i++) {
    const adjusted = adjustServoValue(i, rawValues[i]);
    const angle = servoToAngle(adjusted);

    angleBuffers[i].push(angle);
    if (angleBuffers[i].length > FILTER_SIZE) {
      angleBuffers[i].shift();
    }

    const sum = angleBuffers[i].reduce((a, b) => a + b, 0);
    const avg = sum / angleBuffers[i].length;

    filtered[i] = avg;
  }

  currentAngles = filtered;
  return filtered;
}
