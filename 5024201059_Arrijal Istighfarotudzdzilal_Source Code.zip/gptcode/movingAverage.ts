// Jumlah buffer data untuk filtering (moving average)
const FILTER_SIZE = 32;

// Buat buffer untuk masing-masing servo (6 buah deque)
const angleBuffers: number[][] = Array.from({length: 6}, () => []);

// Simpan sudut servo terakhir yang sudah di-filter
let currentAngles: number[] = Array(6).fill(0);

// Fungsi untuk menambahkan data baru dan menghitung sudut rata-rata (filtered)
export function updateFilteredAngles(rawAngles: number[]): number[] {
  const filtered: number[] = [];

  for (let i = 0; i < 6; i++) {
    // Tambahkan data terbaru ke buffer
    angleBuffers[i].push(rawAngles[i]);

    // Jika buffer melebihi ukuran maksimum, hapus elemen paling lama
    if (angleBuffers[i].length > FILTER_SIZE) {
      angleBuffers[i].shift();
    }

    // Hitung rata-rata dari buffer
    const sum = angleBuffers[i].reduce((acc, val) => acc + val, 0);
    const avg = sum / angleBuffers[i].length;

    filtered[i] = avg;
  }

  currentAngles = filtered;
  return filtered;
}
